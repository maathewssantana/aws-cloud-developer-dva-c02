import ReactFlow, { Background, Controls } from 'reactflow';
import 'reactflow/dist/style.css';

const nodeStyle = {
  background: '#f0f9ff',
  border: '1px solid hsl(201, 91.10%, 48.40%)',
  borderRadius: '20px',
  padding: 10,
  fontSize: 11,
  width: 210,
  textAlign: 'left',
  whiteSpace: 'pre-line',
  cursor: 'default',
  boxShadow: '0 2px 6px rgba(0,0,0,0.05)'
};

const makeNode = (id, title, description, x, y) => ({
  id,
  position: { x, y },
  style: nodeStyle,
  data: {
    label: (
      <div>
        <div className="font-bold text-sm mb-1">{title}</div>
        <div className="text-gray-600 text-xs">{description}</div>
      </div>
    )
  }
});

const nodes = [
  makeNode('0', 'Frontend', 'Página de e-commerce com botão Comprar', -220, 100),
  makeNode('1', 'API Gateway', 'Recebe requisições HTTP do frontend', 0, 100),
  makeNode('2', 'Lambda 1: Recebe Pedido', 'Recebe o pedido via API e envia para a fila SQS', 220, 100),
  makeNode('3', 'SQS FIFO', 'Fila para garantir ordem de processamento dos pedidos', 440, 100),
  makeNode('4', 'Lambda 2: Valida Pedido', 'Valida os dados e publica no EventBridge', 660, 100),
  makeNode('5', 'EventBridge', 'Distribui eventos para funções específicas', 880, 100),
  makeNode('6', 'Lambda 4: Processa Pedido', 'Grava o pedido processado no DynamoDB', 1100, 20),
  makeNode('7', 'Lambda 5: Cancelamento', 'Atualiza pedido como CANCELADO', 1100, 100),
  makeNode('8', 'Lambda 6: Alteração', 'Atualiza itens e status como ALTERADO', 1100, 180),
  makeNode('9', 'DynamoDB', 'Armazena todos os pedidos e atualizações', 1320, 100),
];

const edges = [
  { id: 'e0-1', source: '0', target: '1' }, // ligação do Frontend para API Gateway
  { id: 'e1-2', source: '1', target: '2' },
  { id: 'e2-3', source: '2', target: '3' },
  { id: 'e3-4', source: '3', target: '4' },
  { id: 'e4-5', source: '4', target: '5' },
  { id: 'e5-6', source: '5', target: '6' },
  { id: 'e5-7', source: '5', target: '7' },
  { id: 'e5-8', source: '5', target: '8' },
  { id: 'e6-9', source: '6', target: '9' },
  { id: 'e7-9', source: '7', target: '9' },
  { id: 'e8-9', source: '8', target: '9' },
];

export default function ArquiteturaFlow() {
  return (
    <div style={{ height: '650px', width: '100%' }} className="mb-10">
      <ReactFlow nodes={nodes} edges={edges} fitView>
        <Background />
        <Controls />
      </ReactFlow>
    </div>
  );
}
