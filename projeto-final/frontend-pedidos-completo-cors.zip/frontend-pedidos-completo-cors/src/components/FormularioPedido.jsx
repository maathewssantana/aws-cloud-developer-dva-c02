import { useState } from 'react';

export default function FormularioPedido() {
  const [pedidoId, setPedidoId] = useState('');
  const [clienteId, setClienteId] = useState('');
  const [itens, setItens] = useState([{ produto: '', quantidade: 1 }]);
  const [resposta, setResposta] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      pedidoId,
      clienteId,
      itens
    };

    try {
      const res = await fetch('https://vbkzyxujpa.execute-api.us-east-2.amazonaws.com/dev/pedidos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const json = await res.json();
      setResposta(json);
    } catch (err) {
      console.error(err);
      setResposta({ message: 'Erro ao enviar pedido' });
    }
  };

  const adicionarItem = () => {
    setItens([...itens, { produto: '', quantidade: 1 }]);
  };

  const atualizarItem = (index, key, value) => {
    const novosItens = [...itens];
    novosItens[index][key] = key === 'quantidade' ? Number(value) : value;
    setItens(novosItens);
  };

  return (
    <div className="p-4 bg-white rounded shadow max-w-xl mx-auto mt-6">
      <h2 className="text-xl font-semibold mb-4">Enviar Pedido (API Gateway)</h2>
      <form onSubmit={handleSubmit}>
        <input className="w-full p-2 border mb-2" placeholder="Pedido ID" value={pedidoId} onChange={e => setPedidoId(e.target.value)} />
        <input className="w-full p-2 border mb-2" placeholder="Cliente ID" value={clienteId} onChange={e => setClienteId(e.target.value)} />

        {itens.map((item, idx) => (
          <div key={idx} className="flex gap-2 mb-2">
            <input
              className="w-full p-2 border"
              placeholder="Produto"
              value={item.produto}
              onChange={e => atualizarItem(idx, 'produto', e.target.value)}
            />
            <input
              type="number"
              className="w-24 p-2 border"
              value={item.quantidade}
              onChange={e => atualizarItem(idx, 'quantidade', e.target.value)}
            />
          </div>
        ))}
        <button type="button" onClick={adicionarItem} className="bg-blue-100 text-blue-800 px-3 py-1 rounded mb-4">+ Adicionar Item</button>
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded">Comprar</button>
      </form>

      {resposta && (
        <div className="mt-4 p-2 bg-gray-100 rounded text-sm">
          <pre>{JSON.stringify(resposta, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}
